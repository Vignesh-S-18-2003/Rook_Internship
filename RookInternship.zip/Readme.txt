Its an Ecommerce website created for the task for Rook Internship 

Home Page:
	1. Consists of various mobiles as products with the Name, Price , Order and Add to Cart option
	2. If order is selected it navigated to the address details page
	3. If Add to Cart is selected it navigated to Cart Page

Cart Page:
	1. Consists of products with Name, Increase, Decrease option and Quantity
	2. Checkout Button to navigate to Address page

Address Page:
	1. It requires details of the user and then it will gets authenticated by sms otp in which the user has to type their number in mobile number and then Otp has to verified by the sms
	got at mobile number user entered on.
	2. then once you type your 6 digit pincode then the district and state will updated automatically.
	3. Once clicked next it moves to payment page.

Payment Page :
	1. Here we have to select the delivery type as Normal or Express Delivery
	2. Here we have to select the Payment type as Online or Cash on Delivery
	3. Here we can select Invoice by which invoice pdf will gets downloaded
	4. If Online Payment select Pay now to pay it online by razorpay gateway
	5. If cash on delivery select order now to confirm or place your Order

Order Page :
	1. Here details of your order will be displayed
	2. Confirmation mail would sent to you once order placed or confirmed.

GitHub Link : https://github.com/Vignesh-S-18-2003/Rook-Internship

Hosted Link : https://668c3b68d475269c5a4f5c6a--warm-biscuit-cf3b50.netlify.app

File Link : https://drive.google.com/file/d/1feDRPsvyAQPesOMESOLAbciPOOfjGywz/view?usp=sharing